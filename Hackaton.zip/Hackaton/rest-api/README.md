# REST-API-Server-Codeigniter
REST API Server Sederhana dengan Codeigniter 3
