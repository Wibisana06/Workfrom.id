<?php
defined('BASEPATH') or exit('No direct script access allowed');

class M_user extends CI_Model
{
	public function select_all()
	{
		// $this->db->select('*');
		// $this->db->from('user');
		$query = "SELECT * FROM user";
		$result = $this->db->query($query)->result();
		// $data = $this->db->get();

		return $result;
	}

	public function select_by_id($id)
	{
		$sql = "SELECT * FROM user where id = '{$id}'";

		$data = $this->db->query($sql);

		return $data->row();
	}

	public function select_by_name($name)
	{
		$sql = "SELECT * FROM user where user = '{$name}'";

		$data = $this->db->query($sql);

		return $data->num_rows();
	}

	public function delete($id)
	{
		$sql = "DELETE FROM user WHERE id='" . $id . "'";

		$this->db->query($sql);

		return $this->db->affected_rows();
	}

	public function insert($data)
	{
		

		$sql = "INSERT INTO `user` 
		(`username`,`password`,`email`)
		VALUES (test, test,test)";

		$this->db->query($sql);

		return $this->db->affected_rows();
	}

	public function update($data)
	{

		$sql = "UPDATE `ikt_db`.`user` SET 
		`user` = '" . $data['user'] . "' 
		WHERE `id` = '" . $data['id'] . "';";

		$this->db->query($sql);

		return $this->db->affected_rows();
	}

	public function insert_batch($data)
	{
		$this->db->insert_batch('pegawai', $data);

		return $this->db->affected_rows();
	}

	public function total_rows()
	{
		$data = $this->db->get('planning_sampling');

		return $data->num_rows();
	}
}

/* End of file M_pegawai.php */
/* Location: ./application/models/M_pegawai.php */