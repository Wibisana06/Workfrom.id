<?php

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';
use Restserver\Libraries\REST_Controller;

class Login extends REST_Controller {

    // function __construct($config = 'rest') {
    //     parent::__construct($config);
    //     $this->load->database();
    // }

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }

    //Menampilkan data kontak
    function index_get() {
        $data = array(
            'id' => '2',
            'nama' => '',
            'nomor' => '');
        $this->response($data, 200);
    }

    //Mengirim atau menambah data kontak baru
    function index_post() {


        $username = $this->post('username'); 
        $password = $this->post('password');

        
        $this->db->select('*'); 
        $this->db->from('user');
        $this->db->where('username', $username);
        $this->db->where('password', $password);
        $query = $this->db->get();
        
        if ($query->num_rows() > 0) {
            $result = $query->result(); 
            $data = array(
                'message' => 'success',
                'data' => $result);
            $this->response($data, 200);
        } else {
            $data = array(
                'message' => 'failed',
                'err' => 'Username atau Password Salah');
            $this->response($data, 502);
        }        


    }

}
?>
